import SentinelPage from '@/components/admin/SentinelPage';

export default function AdminSentinelPage() {
  return <SentinelPage />;
}